"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"

interface Produto {
  id: string
  nome: string
  preco: number
  estoque: number
  descricao: string
  imagem: string
}

interface ItemCarrinho {
  produto: Produto
  quantidade: number
}

interface CarrinhoContextType {
  carrinho: ItemCarrinho[]
  adicionarAoCarrinho: (produto: Produto) => void
  removerDoCarrinho: (produtoId: string) => void
  limparCarrinho: () => void
  getQuantidadeNoCarrinho: (produtoId: string) => number
  getTotalCarrinho: () => number
  getTotalItens: () => number
  atualizarQuantidade: (produtoId: string, quantidade: number) => void
}

const CarrinhoContext = createContext<CarrinhoContextType | undefined>(undefined)

export function CarrinhoProvider({ children }: { children: ReactNode }) {
  const [carrinho, setCarrinho] = useState<ItemCarrinho[]>([])
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    const carrinhoSalvo = localStorage.getItem("carrinho")
    if (carrinhoSalvo) {
      try {
        setCarrinho(JSON.parse(carrinhoSalvo))
      } catch (error) {
        console.error("Erro ao carregar carrinho:", error)
      }
    }
    setIsLoaded(true)
  }, [])

  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem("carrinho", JSON.stringify(carrinho))
    }
  }, [carrinho, isLoaded])

  const adicionarAoCarrinho = (produto: Produto) => {
    setCarrinho((prev) => {
      const itemExistente = prev.find((item) => item.produto.id === produto.id)
      if (itemExistente) {
        if (itemExistente.quantidade >= produto.estoque) {
          return prev // Don't add if already at stock limit
        }
        return prev.map((item) =>
          item.produto.id === produto.id ? { ...item, quantidade: item.quantidade + 1 } : item,
        )
      }
      return [...prev, { produto, quantidade: 1 }]
    })
  }

  const removerDoCarrinho = (produtoId: string) => {
    setCarrinho((prev) => {
      const itemExistente = prev.find((item) => item.produto.id === produtoId)
      if (itemExistente && itemExistente.quantidade > 1) {
        return prev.map((item) => (item.produto.id === produtoId ? { ...item, quantidade: item.quantidade - 1 } : item))
      }
      return prev.filter((item) => item.produto.id !== produtoId)
    })
  }

  const atualizarQuantidade = (produtoId: string, quantidade: number) => {
    if (quantidade <= 0) {
      setCarrinho((prev) => prev.filter((item) => item.produto.id !== produtoId))
      return
    }

    setCarrinho((prev) => {
      return prev.map((item) => {
        if (item.produto.id === produtoId) {
          const novaQuantidade = Math.min(quantidade, item.produto.estoque)
          return { ...item, quantidade: novaQuantidade }
        }
        return item
      })
    })
  }

  const limparCarrinho = () => {
    setCarrinho([])
  }

  const getQuantidadeNoCarrinho = (produtoId: string) => {
    const item = carrinho.find((item) => item.produto.id === produtoId)
    return item ? item.quantidade : 0
  }

  const getTotalCarrinho = () => {
    return carrinho.reduce((total, item) => total + item.produto.preco * item.quantidade, 0)
  }

  const getTotalItens = () => {
    return carrinho.reduce((total, item) => total + item.quantidade, 0)
  }

  return (
    <CarrinhoContext.Provider
      value={{
        carrinho,
        adicionarAoCarrinho,
        removerDoCarrinho,
        limparCarrinho,
        getQuantidadeNoCarrinho,
        getTotalCarrinho,
        getTotalItens,
        atualizarQuantidade,
      }}
    >
      {children}
    </CarrinhoContext.Provider>
  )
}

export function useCarrinho() {
  const context = useContext(CarrinhoContext)
  if (context === undefined) {
    throw new Error("useCarrinho must be used within a CarrinhoProvider")
  }
  return context
}
