"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Plus, Minus, Trash2, ShoppingBag } from "lucide-react"
import { useCarrinho } from "@/contexts/carrinho-context"
import { useState } from "react"

interface CarrinhoSidebarProps {
  onFinalizarPedido?: () => void
}

export function CarrinhoSidebar({ onFinalizarPedido }: CarrinhoSidebarProps) {
  const {
    carrinho,
    adicionarAoCarrinho,
    removerDoCarrinho,
    limparCarrinho,
    getTotalCarrinho,
    getTotalItens,
    atualizarQuantidade,
  } = useCarrinho()

  const [quantidadeInputs, setQuantidadeInputs] = useState<{ [key: string]: string }>({})

  const handleQuantidadeChange = (produtoId: string, value: string) => {
    setQuantidadeInputs((prev) => ({ ...prev, [produtoId]: value }))
  }

  const handleQuantidadeBlur = (produtoId: string, value: string) => {
    const quantidade = Number.parseInt(value) || 0
    atualizarQuantidade(produtoId, quantidade)
    setQuantidadeInputs((prev) => {
      const newInputs = { ...prev }
      delete newInputs[produtoId]
      return newInputs
    })
  }

  const getDisplayQuantidade = (produtoId: string, quantidade: number) => {
    return quantidadeInputs[produtoId] !== undefined ? quantidadeInputs[produtoId] : quantidade.toString()
  }

  return (
    <Card className="sticky top-4 h-fit">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-card-foreground">
          <ShoppingBag className="h-5 w-5" />
          Carrinho de Compras
          {getTotalItens() > 0 && (
            <Badge variant="secondary" className="ml-auto">
              {getTotalItens()} {getTotalItens() === 1 ? "item" : "itens"}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {carrinho.length === 0 ? (
          <div className="text-center py-8">
            <ShoppingBag className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Seu carrinho está vazio</p>
            <p className="text-sm text-muted-foreground mt-1">Adicione produtos para começar suas compras</p>
          </div>
        ) : (
          <>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {carrinho.map((item) => (
                <div key={item.produto.id} className="border rounded-lg p-3 space-y-3">
                  <div className="flex gap-3">
                    <div className="w-16 h-16 bg-secondary/50 rounded-md flex items-center justify-center flex-shrink-0">
                      <img
                        src={item.produto.imagem || "/placeholder.svg"}
                        alt={item.produto.nome}
                        className="w-full h-full object-cover rounded-md"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-sm text-card-foreground line-clamp-2">{item.produto.nome}</h4>
                      <p className="text-sm text-accent font-semibold">R$ {item.produto.preco.toFixed(2)}</p>
                      {item.produto.estoque <= 5 && (
                        <Badge variant="outline" className="text-xs">
                          Apenas {item.produto.estoque} restantes
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => removerDoCarrinho(item.produto.id)}
                        className="h-8 w-8 p-0"
                      >
                        <Minus className="h-3 w-3" />
                      </Button>

                      <Input
                        type="number"
                        min="1"
                        max={item.produto.estoque}
                        value={getDisplayQuantidade(item.produto.id, item.quantidade)}
                        onChange={(e) => handleQuantidadeChange(item.produto.id, e.target.value)}
                        onBlur={(e) => handleQuantidadeBlur(item.produto.id, e.target.value)}
                        className="w-16 h-8 text-center text-sm"
                      />

                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => adicionarAoCarrinho(item.produto)}
                        disabled={item.quantidade >= item.produto.estoque}
                        className="h-8 w-8 p-0"
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-card-foreground">
                        R$ {(item.produto.preco * item.quantidade).toFixed(2)}
                      </span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => atualizarQuantidade(item.produto.id, 0)}
                        className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t pt-4 space-y-4">
              <div className="flex justify-between items-center">
                <span className="font-bold text-lg text-card-foreground">Total:</span>
                <span className="font-bold text-xl text-accent">R$ {getTotalCarrinho().toFixed(2)}</span>
              </div>

              <div className="space-y-2">
                <Button
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                  onClick={onFinalizarPedido}
                >
                  Finalizar Pedido
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={limparCarrinho}
                  className="w-full text-destructive hover:text-destructive bg-transparent"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Limpar Carrinho
                </Button>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
