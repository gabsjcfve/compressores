"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { ShoppingCart, Plus, Minus, Settings, Edit, Trash2 } from "lucide-react"
import Image from "next/image"

interface Produto {
  id: string
  nome: string
  preco: number
  descricao: string
  imagem: string
}

interface ItemPedido {
  produto_id: string
  nome: string
  preco: number
  quantidade: number
}

export default function ControlPanel() {
  const [produtos, setProdutos] = useState<Produto[]>([])
  const [loading, setLoading] = useState(true)
  const [quantidades, setQuantidades] = useState<Record<string, number>>({})
  const [formaPagamento, setFormaPagamento] = useState("")
  const [processandoPedido, setProcessandoPedido] = useState(false)
  const [adminMode, setAdminMode] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Produto | null>(null)
  const [productForm, setProductForm] = useState({
    nome: "",
    preco: "",
    descricao: "",
  })

  useEffect(() => {
    fetchProdutos()
  }, [])

  const fetchProdutos = async () => {
    try {
      console.log("[v0] Iniciando busca de produtos...")
      const response = await fetch(`/api/produtos?t=${Date.now()}`)

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()
      console.log("[v0] Produtos recebidos:", data)
      console.log("[v0] Total de produtos:", data.length)
      console.log(
        "[v0] Nomes dos produtos:",
        data.map((p: Produto) => p.nome),
      )
      setProdutos(data)

      const initialQuantidades: Record<string, number> = {}
      data.forEach((produto: Produto) => {
        initialQuantidades[produto.id] = 0
      })
      setQuantidades(initialQuantidades)
    } catch (error) {
      console.error("[v0] Erro ao buscar produtos:", error)
      setProdutos([])
    } finally {
      setLoading(false)
    }
  }

  const updateQuantidade = (produtoId: string, novaQuantidade: number) => {
    setQuantidades((prev) => ({
      ...prev,
      [produtoId]: Math.max(0, novaQuantidade),
    }))
  }

  const getItensPedido = (): ItemPedido[] => {
    return produtos
      .filter((produto) => quantidades[produto.id] > 0)
      .map((produto) => ({
        produto_id: produto.id,
        nome: produto.nome,
        preco: produto.preco,
        quantidade: quantidades[produto.id],
      }))
  }

  const getTotal = (): number => {
    return getItensPedido().reduce((total, item) => total + item.preco * item.quantidade, 0)
  }

  const generateRandomClientName = (): string => {
    const nomes = ["Cliente", "Mesa", "Pedido", "Consumidor"]
    const numeros = Math.floor(Math.random() * 1000) + 1
    return `${nomes[Math.floor(Math.random() * nomes.length)]} ${numeros}`
  }

  const finalizarPedido = async () => {
    const itens = getItensPedido()

    if (itens.length === 0) {
      alert("Adicione pelo menos um item ao pedido!")
      return
    }

    if (!formaPagamento) {
      alert("Selecione uma forma de pagamento!")
      return
    }

    setProcessandoPedido(true)

    try {
      const nomeClienteAleatorio = generateRandomClientName()

      console.log("[v0] Enviando pedido:", {
        cliente_nome: nomeClienteAleatorio,
        forma_pagamento: formaPagamento,
        total: getTotal(),
        itens: itens.map((item) => ({
          nome_produto: item.nome,
          quantidade: item.quantidade,
          preco_unitario: item.preco,
          subtotal: item.preco * item.quantidade,
        })),
      })

      const response = await fetch("/api/pedidos", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          cliente_nome: nomeClienteAleatorio,
          forma_pagamento: formaPagamento,
          total: getTotal(),
          itens: itens.map((item) => ({
            nome_produto: item.nome,
            quantidade: item.quantidade,
            preco_unitario: item.preco,
            subtotal: item.preco * item.quantidade,
          })),
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Erro ao criar pedido")
      }

      const pedido = await response.json()

      console.log("[v0] Pedido criado com sucesso:", pedido)

      setQuantidades((prev) => {
        const reset: Record<string, number> = {}
        Object.keys(prev).forEach((key) => {
          reset[key] = 0
        })
        return reset
      })
      setFormaPagamento("")

      alert(
        `Pedido #${pedido.numero_pedido} criado com sucesso!\nCliente: ${nomeClienteAleatorio}\nTotal: R$ ${getTotal().toFixed(2)}`,
      )
    } catch (error) {
      console.error("[v0] Erro ao finalizar pedido:", error)
      alert(`Erro ao finalizar pedido: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    } finally {
      setProcessandoPedido(false)
    }
  }

  const saveProduct = async () => {
    try {
      const productData = {
        nome: productForm.nome,
        preco: Number.parseFloat(productForm.preco),
        descricao: productForm.descricao,
      }

      const response = await fetch("/api/produtos", {
        method: editingProduct ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(editingProduct ? { ...productData, id: editingProduct.id } : productData),
      })

      if (!response.ok) {
        throw new Error("Erro ao salvar produto")
      }

      setProductForm({ nome: "", preco: "", descricao: "" })
      setEditingProduct(null)
      fetchProdutos()
      alert(editingProduct ? "Produto atualizado com sucesso!" : "Produto criado com sucesso!")
    } catch (error) {
      console.error("Erro ao salvar produto:", error)
      alert("Erro ao salvar produto")
    }
  }

  const deleteProduct = async (productId: string) => {
    if (!confirm("Tem certeza que deseja excluir este produto?")) return

    try {
      const response = await fetch(`/api/produtos?id=${productId}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Erro ao excluir produto")
      }

      fetchProdutos()
      alert("Produto excluído com sucesso!")
    } catch (error) {
      console.error("Erro ao excluir produto:", error)
      alert("Erro ao excluir produto")
    }
  }

  const startEditProduct = (produto: Produto) => {
    setEditingProduct(produto)
    setProductForm({
      nome: produto.nome,
      preco: produto.preco.toString(),
      descricao: produto.descricao,
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-green-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando produtos...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-green-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-6">
              <Image
                src="/images/guararema-logo.png"
                alt="Guararema Sabbia Club"
                width={120}
                height={120}
                className="rounded-lg shadow-md"
              />
              <div>
                <h1 className="text-3xl font-bold text-gray-800 mb-2">Guararema Sabbia Club</h1>
                <p className="text-gray-600">Sistema de pedidos e controle de vendas</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant={adminMode ? "default" : "outline"}
                onClick={() => setAdminMode(!adminMode)}
                className={
                  adminMode
                    ? "bg-orange-500 hover:bg-orange-600"
                    : "border-orange-500 text-orange-500 hover:bg-orange-50"
                }
              >
                <Settings className="h-4 w-4 mr-2" />
                {adminMode ? "Sair Admin" : "Modo Admin"}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setLoading(true)
                  fetchProdutos()
                }}
                disabled={loading}
                className="border-green-500 text-green-500 hover:bg-green-50"
              >
                {loading ? "Carregando..." : "Atualizar Produtos"}
              </Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
              <CardHeader className="bg-gradient-to-r from-orange-500 to-yellow-500 text-white rounded-t-lg">
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShoppingCart className="h-5 w-5" />
                    Produtos Disponíveis
                  </div>
                  {adminMode && (
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => {
                            setEditingProduct(null)
                            setProductForm({ nome: "", preco: "", descricao: "" })
                          }}
                        >
                          <Plus className="h-4 w-4 mr-1" />
                          Novo Produto
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>{editingProduct ? "Editar Produto" : "Novo Produto"}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="nome">Nome do Produto</Label>
                            <Input
                              id="nome"
                              value={productForm.nome}
                              onChange={(e) => setProductForm((prev) => ({ ...prev, nome: e.target.value }))}
                              placeholder="Ex: X-Burger"
                            />
                          </div>
                          <div>
                            <Label htmlFor="preco">Preço (R$)</Label>
                            <Input
                              id="preco"
                              type="number"
                              step="0.01"
                              value={productForm.preco}
                              onChange={(e) => setProductForm((prev) => ({ ...prev, preco: e.target.value }))}
                              placeholder="Ex: 25.00"
                            />
                          </div>
                          <div>
                            <Label htmlFor="descricao">Descrição</Label>
                            <Textarea
                              id="descricao"
                              value={productForm.descricao}
                              onChange={(e) => setProductForm((prev) => ({ ...prev, descricao: e.target.value }))}
                              placeholder="Descrição do produto..."
                            />
                          </div>
                          <Button
                            onClick={saveProduct}
                            className="w-full bg-orange-500 hover:bg-orange-600"
                            disabled={!productForm.nome || !productForm.preco}
                          >
                            {editingProduct ? "Atualizar" : "Criar"} Produto
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {produtos.map((produto) => (
                    <div
                      key={produto.id}
                      className="border border-orange-200 rounded-lg p-4 space-y-3 bg-white shadow-sm hover:shadow-md transition-shadow"
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg text-gray-800">{produto.nome}</h3>
                          <p className="text-2xl font-bold text-green-600">R$ {produto.preco.toFixed(2)}</p>
                        </div>
                        {adminMode && (
                          <div className="flex gap-1">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="ghost" size="sm" onClick={() => startEditProduct(produto)}>
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Editar Produto</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div>
                                    <Label htmlFor="nome">Nome do Produto</Label>
                                    <Input
                                      id="nome"
                                      value={productForm.nome}
                                      onChange={(e) => setProductForm((prev) => ({ ...prev, nome: e.target.value }))}
                                    />
                                  </div>
                                  <div>
                                    <Label htmlFor="preco">Preço (R$)</Label>
                                    <Input
                                      id="preco"
                                      type="number"
                                      step="0.01"
                                      value={productForm.preco}
                                      onChange={(e) => setProductForm((prev) => ({ ...prev, preco: e.target.value }))}
                                    />
                                  </div>
                                  <div>
                                    <Label htmlFor="descricao">Descrição</Label>
                                    <Textarea
                                      id="descricao"
                                      value={productForm.descricao}
                                      onChange={(e) =>
                                        setProductForm((prev) => ({ ...prev, descricao: e.target.value }))
                                      }
                                    />
                                  </div>
                                  <Button
                                    onClick={saveProduct}
                                    className="w-full bg-orange-500 hover:bg-orange-600"
                                    disabled={!productForm.nome || !productForm.preco}
                                  >
                                    Atualizar Produto
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteProduct(produto.id)}
                              className="text-red-500 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>

                      {!adminMode && (
                        <>
                          <div className="flex items-center justify-between">
                            <Label htmlFor={`qty-${produto.id}`}>Quantidade:</Label>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => updateQuantidade(produto.id, quantidades[produto.id] - 1)}
                                disabled={quantidades[produto.id] <= 0}
                                className="border-orange-300 text-orange-600 hover:bg-orange-50"
                              >
                                <Minus className="h-4 w-4" />
                              </Button>
                              <Input
                                id={`qty-${produto.id}`}
                                type="number"
                                min="0"
                                value={quantidades[produto.id] || 0}
                                onChange={(e) => updateQuantidade(produto.id, Number.parseInt(e.target.value) || 0)}
                                className="w-20 text-center border-orange-300 focus:border-orange-500"
                              />
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => updateQuantidade(produto.id, quantidades[produto.id] + 1)}
                                className="border-orange-300 text-orange-600 hover:bg-orange-50"
                              >
                                <Plus className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>

                          {quantidades[produto.id] > 0 && (
                            <div className="text-sm text-green-600 font-medium">
                              Subtotal: R$ {(produto.preco * quantidades[produto.id]).toFixed(2)}
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {!adminMode && (
            <div className="lg:col-span-1">
              <Card className="sticky top-6 shadow-lg border-0 bg-white/80 backdrop-blur-sm">
                <CardHeader className="bg-gradient-to-r from-green-500 to-teal-500 text-white rounded-t-lg">
                  <CardTitle>Resumo do Pedido</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4 p-6">
                  <div>
                    <Label htmlFor="forma-pagamento">Forma de Pagamento</Label>
                    <Select value={formaPagamento} onValueChange={setFormaPagamento}>
                      <SelectTrigger className="border-green-300 focus:border-green-500">
                        <SelectValue placeholder="Selecione a forma de pagamento" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pix">PIX</SelectItem>
                        <SelectItem value="cartao_credito">Cartão Crédito</SelectItem>
                        <SelectItem value="cartao_debito">Cartão Débito</SelectItem>
                        <SelectItem value="dinheiro">Dinheiro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <h4 className="font-semibold text-gray-800">Itens do Pedido:</h4>
                    {getItensPedido().length === 0 ? (
                      <p className="text-sm text-gray-500">Nenhum item selecionado</p>
                    ) : (
                      getItensPedido().map((item) => (
                        <div key={item.produto_id} className="flex justify-between text-sm">
                          <span>
                            {item.quantidade}x {item.nome}
                          </span>
                          <span className="text-green-600 font-medium">
                            R$ {(item.preco * item.quantidade).toFixed(2)}
                          </span>
                        </div>
                      ))
                    )}
                  </div>

                  <Separator />

                  <div className="flex justify-between items-center text-lg font-bold">
                    <span className="text-gray-800">Total:</span>
                    <span className="text-green-600">R$ {getTotal().toFixed(2)}</span>
                  </div>

                  <Button
                    className="w-full bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white font-semibold"
                    size="lg"
                    onClick={finalizarPedido}
                    disabled={processandoPedido || getItensPedido().length === 0}
                  >
                    {processandoPedido ? "Processando..." : "Finalizar Pedido"}
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
