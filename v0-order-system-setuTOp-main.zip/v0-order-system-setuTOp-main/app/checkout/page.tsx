"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, CreditCard, Smartphone, Banknote, ShoppingBag, Loader2 } from "lucide-react"
import { useCarrinho } from "@/contexts/carrinho-context"
import Link from "next/link"

interface DadosCliente {
  nome: string
  email: string
  telefone: string
  endereco: string
}

export default function CheckoutPage() {
  const router = useRouter()
  const { carrinho, getTotalCarrinho, getTotalItens, limparCarrinho } = useCarrinho()

  const [dadosCliente, setDadosCliente] = useState<DadosCliente>({
    nome: "",
    email: "",
    telefone: "",
    endereco: "",
  })

  const [formaPagamento, setFormaPagamento] = useState<string>("")
  const [desconto, setDesconto] = useState(0)
  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState<Partial<DadosCliente & { formaPagamento: string }>>({})

  const subtotal = getTotalCarrinho()
  const total = subtotal - desconto

  const handleInputChange = (field: keyof DadosCliente, value: string) => {
    setDadosCliente((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }))
    }
  }

  const validateForm = () => {
    const newErrors: Partial<DadosCliente & { formaPagamento: string }> = {}

    if (!dadosCliente.nome.trim()) newErrors.nome = "Nome é obrigatório"
    if (!dadosCliente.email.trim()) newErrors.email = "Email é obrigatório"
    if (!dadosCliente.telefone.trim()) newErrors.telefone = "Telefone é obrigatório"
    if (!dadosCliente.endereco.trim()) newErrors.endereco = "Endereço é obrigatório"
    if (!formaPagamento) newErrors.formaPagamento = "Forma de pagamento é obrigatória"

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (dadosCliente.email && !emailRegex.test(dadosCliente.email)) {
      newErrors.email = "Email inválido"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleFinalizarPedido = async () => {
    if (!validateForm()) return

    setLoading(true)

    try {
      const itens = carrinho.map((item) => ({
        produto_id: item.produto.id,
        quantidade: item.quantidade,
        preco_unitario: item.produto.preco,
        subtotal: item.produto.preco * item.quantidade,
      }))

      const pedidoData = {
        cliente_nome: dadosCliente.nome,
        cliente_email: dadosCliente.email,
        cliente_telefone: dadosCliente.telefone,
        cliente_endereco: dadosCliente.endereco,
        forma_pagamento: formaPagamento,
        itens,
        subtotal,
        desconto,
        total,
      }

      const response = await fetch("/api/pedidos", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(pedidoData),
      })

      const result = await response.json()

      if (response.ok) {
        limparCarrinho()
        router.push(`/pedido-confirmado?id=${result.pedido_id}`)
      } else {
        throw new Error(result.error || "Erro ao criar pedido")
      }
    } catch (error) {
      console.error("Erro ao finalizar pedido:", error)
      alert("Erro ao finalizar pedido. Tente novamente.")
    } finally {
      setLoading(false)
    }
  }

  if (carrinho.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="text-center py-8">
            <ShoppingBag className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">Carrinho Vazio</h2>
            <p className="text-muted-foreground mb-4">Adicione produtos ao carrinho antes de finalizar o pedido.</p>
            <Link href="/">
              <Button>Continuar Comprando</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-primary-foreground hover:bg-primary-foreground/10">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">Finalizar Pedido</h1>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Formulário de Checkout */}
          <div className="lg:col-span-2 space-y-6">
            {/* Dados do Cliente */}
            <Card>
              <CardHeader>
                <CardTitle>Dados do Cliente</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nome">Nome Completo *</Label>
                    <Input
                      id="nome"
                      value={dadosCliente.nome}
                      onChange={(e) => handleInputChange("nome", e.target.value)}
                      placeholder="Seu nome completo"
                      className={errors.nome ? "border-destructive" : ""}
                    />
                    {errors.nome && <p className="text-sm text-destructive mt-1">{errors.nome}</p>}
                  </div>

                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={dadosCliente.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      placeholder="seu@email.com"
                      className={errors.email ? "border-destructive" : ""}
                    />
                    {errors.email && <p className="text-sm text-destructive mt-1">{errors.email}</p>}
                  </div>
                </div>

                <div>
                  <Label htmlFor="telefone">Telefone *</Label>
                  <Input
                    id="telefone"
                    value={dadosCliente.telefone}
                    onChange={(e) => handleInputChange("telefone", e.target.value)}
                    placeholder="(11) 99999-9999"
                    className={errors.telefone ? "border-destructive" : ""}
                  />
                  {errors.telefone && <p className="text-sm text-destructive mt-1">{errors.telefone}</p>}
                </div>

                <div>
                  <Label htmlFor="endereco">Endereço Completo *</Label>
                  <Textarea
                    id="endereco"
                    value={dadosCliente.endereco}
                    onChange={(e) => handleInputChange("endereco", e.target.value)}
                    placeholder="Rua, número, bairro, cidade, CEP"
                    className={errors.endereco ? "border-destructive" : ""}
                    rows={3}
                  />
                  {errors.endereco && <p className="text-sm text-destructive mt-1">{errors.endereco}</p>}
                </div>
              </CardContent>
            </Card>

            {/* Forma de Pagamento */}
            <Card>
              <CardHeader>
                <CardTitle>Forma de Pagamento</CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup value={formaPagamento} onValueChange={setFormaPagamento}>
                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-secondary/50 transition-colors">
                    <RadioGroupItem value="pix" id="pix" />
                    <Label htmlFor="pix" className="flex items-center gap-3 cursor-pointer flex-1">
                      <Smartphone className="h-5 w-5 text-primary" />
                      <div>
                        <p className="font-medium">PIX</p>
                        <p className="text-sm text-muted-foreground">Pagamento instantâneo</p>
                      </div>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-secondary/50 transition-colors">
                    <RadioGroupItem value="cartao" id="cartao" />
                    <Label htmlFor="cartao" className="flex items-center gap-3 cursor-pointer flex-1">
                      <CreditCard className="h-5 w-5 text-primary" />
                      <div>
                        <p className="font-medium">Cartão de Crédito/Débito</p>
                        <p className="text-sm text-muted-foreground">Visa, Mastercard, Elo</p>
                      </div>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-secondary/50 transition-colors">
                    <RadioGroupItem value="dinheiro" id="dinheiro" />
                    <Label htmlFor="dinheiro" className="flex items-center gap-3 cursor-pointer flex-1">
                      <Banknote className="h-5 w-5 text-primary" />
                      <div>
                        <p className="font-medium">Dinheiro</p>
                        <p className="text-sm text-muted-foreground">Pagamento na entrega</p>
                      </div>
                    </Label>
                  </div>
                </RadioGroup>
                {errors.formaPagamento && <p className="text-sm text-destructive mt-2">{errors.formaPagamento}</p>}
              </CardContent>
            </Card>
          </div>

          {/* Resumo do Pedido */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle>Resumo do Pedido</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {carrinho.map((item) => (
                    <div key={item.produto.id} className="flex justify-between items-start">
                      <div className="flex-1">
                        <p className="font-medium text-sm">{item.produto.nome}</p>
                        <p className="text-sm text-muted-foreground">
                          {item.quantidade}x R$ {item.produto.preco.toFixed(2)}
                        </p>
                      </div>
                      <p className="font-medium">R$ {(item.produto.preco * item.quantidade).toFixed(2)}</p>
                    </div>
                  ))}
                </div>

                <Separator />

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal ({getTotalItens()} itens)</span>
                    <span>R$ {subtotal.toFixed(2)}</span>
                  </div>

                  {desconto > 0 && (
                    <div className="flex justify-between text-accent">
                      <span>Desconto</span>
                      <span>-R$ {desconto.toFixed(2)}</span>
                    </div>
                  )}

                  <Separator />

                  <div className="flex justify-between text-lg font-bold">
                    <span>Total</span>
                    <span className="text-accent">R$ {total.toFixed(2)}</span>
                  </div>
                </div>

                <Button
                  className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
                  onClick={handleFinalizarPedido}
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Processando...
                    </>
                  ) : (
                    "Finalizar Pedido"
                  )}
                </Button>

                <p className="text-xs text-muted-foreground text-center">
                  Ao finalizar o pedido, você concorda com nossos termos de uso.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
