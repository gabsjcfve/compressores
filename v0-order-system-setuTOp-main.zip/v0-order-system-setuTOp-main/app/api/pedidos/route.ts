import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const body = await request.json()

    const { cliente_nome, forma_pagamento, itens, total } = body

    if (!cliente_nome || !forma_pagamento || !itens || itens.length === 0) {
      return NextResponse.json({ error: "Campos obrigatórios: cliente_nome, forma_pagamento, itens" }, { status: 400 })
    }

    if (!supabase) {
      console.error("Supabase client not initialized")
      return NextResponse.json({ error: "Erro de configuração do servidor" }, { status: 500 })
    }

    const { data: sequenceData } = await supabase.rpc("nextval", { sequence_name: "numero_pedido_seq" })
    const numeroPedido = sequenceData || Math.floor(Math.random() * 10000)

    const itensParaInserir = itens.map((item: any) => ({
      numero_pedido: numeroPedido,
      nome_produto: item.nome_produto,
      quantidade: item.quantidade,
      preco_unitario: item.preco_unitario,
      subtotal: item.subtotal,
      total_pedido: total,
      forma_pagamento,
      cliente_nome,
    }))

    const { error: pedidoError } = await supabase.from("pedidos_completos").insert(itensParaInserir)

    if (pedidoError) {
      console.error("Erro ao criar pedido:", pedidoError)
      return NextResponse.json({ error: pedidoError.message }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      numero_pedido: numeroPedido,
      message: "Pedido criado com sucesso!",
    })
  } catch (error) {
    console.error("Erro interno:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
