import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = await createClient()

    const { data: produtos, error } = await supabase.from("produtos_menu").select("*").order("nome")

    if (error) {
      console.error("Erro ao buscar produtos:", error)
      return NextResponse.json({ error: "Erro ao buscar produtos" }, { status: 500 })
    }

    return NextResponse.json(produtos)
  } catch (error) {
    console.error("Erro interno:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const supabase = await createClient()
    const body = await request.json()

    const { nome, preco, descricao } = body

    if (!nome || !preco) {
      return NextResponse.json({ error: "Nome e preço são obrigatórios" }, { status: 400 })
    }

    const { data: produto, error } = await supabase
      .from("produtos_menu")
      .insert([
        {
          nome,
          preco: Number.parseFloat(preco),
          descricao: descricao || "",
          imagem: "/placeholder.svg?height=300&width=300",
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("Erro ao criar produto:", error)
      return NextResponse.json({ error: "Erro ao criar produto" }, { status: 500 })
    }

    return NextResponse.json(produto)
  } catch (error) {
    console.error("Erro interno:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const supabase = await createClient()
    const body = await request.json()

    const { id, nome, preco, descricao } = body

    if (!id || !nome || !preco) {
      return NextResponse.json({ error: "ID, nome e preço são obrigatórios" }, { status: 400 })
    }

    const { data: produto, error } = await supabase
      .from("produtos_menu")
      .update({
        nome,
        preco: Number.parseFloat(preco),
        descricao: descricao || "",
      })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error("Erro ao atualizar produto:", error)
      return NextResponse.json({ error: "Erro ao atualizar produto" }, { status: 500 })
    }

    return NextResponse.json(produto)
  } catch (error) {
    console.error("Erro interno:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const supabase = await createClient()
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "ID é obrigatório" }, { status: 400 })
    }

    const { error } = await supabase.from("produtos_menu").delete().eq("id", id)

    if (error) {
      console.error("Erro ao excluir produto:", error)
      return NextResponse.json({ error: "Erro ao excluir produto" }, { status: 500 })
    }

    return NextResponse.json({ message: "Produto excluído com sucesso" })
  } catch (error) {
    console.error("Erro interno:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
