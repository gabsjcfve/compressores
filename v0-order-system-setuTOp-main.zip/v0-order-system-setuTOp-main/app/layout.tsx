import type React from "react"
import type { Metadata } from "next"
import { Work_Sans, Open_Sans } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { Suspense } from "react"
import { CarrinhoProvider } from "@/contexts/carrinho-context"
import "./globals.css"

const workSans = Work_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-work-sans",
  weight: ["400", "600", "700"],
})

const openSans = Open_Sans({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-open-sans",
  weight: ["400", "500"],
})

export const metadata: Metadata = {
  title: "Sistema de Pedidos - Loja Online",
  description: "Sistema completo de pedidos com carrinho de compras",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR">
      <body className={`font-sans ${workSans.variable} ${openSans.variable}`}>
        <CarrinhoProvider>
          <Suspense fallback={null}>{children}</Suspense>
        </CarrinhoProvider>
        <Analytics />
      </body>
    </html>
  )
}
