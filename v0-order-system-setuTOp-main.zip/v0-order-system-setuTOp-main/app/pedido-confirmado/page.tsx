"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Package, Clock, ArrowLeft } from "lucide-react"
import Link from "next/link"

interface Pedido {
  id: string
  cliente_nome: string
  cliente_email: string
  forma_pagamento: string
  total: number
  status: string
  created_at: string
}

export default function PedidoConfirmadoPage() {
  const searchParams = useSearchParams()
  const pedidoId = searchParams.get("id")
  const [pedido, setPedido] = useState<Pedido | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (pedidoId) {
      // In a real app, you would fetch the order details from the API
      // For now, we'll simulate the order data
      setTimeout(() => {
        setPedido({
          id: pedidoId,
          cliente_nome: "Cliente",
          cliente_email: "cliente@email.com",
          forma_pagamento: "pix",
          total: 0,
          status: "pendente",
          created_at: new Date().toISOString(),
        })
        setLoading(false)
      }, 1000)
    }
  }, [pedidoId])

  const getFormaPagamentoLabel = (forma: string) => {
    switch (forma) {
      case "pix":
        return "PIX"
      case "cartao":
        return "Cartão"
      case "dinheiro":
        return "Dinheiro"
      default:
        return forma
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pendente":
        return (
          <Badge variant="outline" className="text-yellow-600">
            <Clock className="h-3 w-3 mr-1" />
            Pendente
          </Badge>
        )
      case "confirmado":
        return (
          <Badge variant="default" className="text-green-600">
            <Package className="h-3 w-3 mr-1" />
            Confirmado
          </Badge>
        )
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando detalhes do pedido...</p>
        </div>
      </div>
    )
  }

  if (!pedido) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="text-center py-8">
            <h2 className="text-xl font-bold mb-2">Pedido não encontrado</h2>
            <p className="text-muted-foreground mb-4">Não foi possível encontrar os detalhes do seu pedido.</p>
            <Link href="/">
              <Button>Voltar à Loja</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-primary-foreground shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="text-primary-foreground hover:bg-primary-foreground/10">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar à Loja
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">Pedido Confirmado</h1>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Confirmação */}
          <Card className="mb-6">
            <CardContent className="text-center py-8">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-card-foreground mb-2">Pedido Realizado com Sucesso!</h2>
              <p className="text-muted-foreground mb-4">Seu pedido foi recebido e está sendo processado.</p>
              <div className="bg-secondary/50 rounded-lg p-4 inline-block">
                <p className="text-sm text-muted-foreground">Número do Pedido</p>
                <p className="text-xl font-bold text-card-foreground">#{pedido.id.slice(0, 8).toUpperCase()}</p>
              </div>
            </CardContent>
          </Card>

          {/* Detalhes do Pedido */}
          <Card>
            <CardHeader>
              <CardTitle>Detalhes do Pedido</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <div className="mt-1">{getStatusBadge(pedido.status)}</div>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground">Forma de Pagamento</p>
                  <p className="font-medium">{getFormaPagamentoLabel(pedido.forma_pagamento)}</p>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground">Data do Pedido</p>
                  <p className="font-medium">
                    {new Date(pedido.created_at).toLocaleDateString("pt-BR", {
                      day: "2-digit",
                      month: "2-digit",
                      year: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground">Email de Confirmação</p>
                  <p className="font-medium">{pedido.cliente_email}</p>
                </div>
              </div>

              <div className="border-t pt-4">
                <h3 className="font-semibold mb-2">Próximos Passos</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Você receberá um email de confirmação em breve
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Entraremos em contato para confirmar os detalhes da entrega
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    Acompanhe o status do seu pedido pelo email fornecido
                  </li>
                </ul>
              </div>

              <div className="flex gap-4 pt-4">
                <Link href="/" className="flex-1">
                  <Button variant="outline" className="w-full bg-transparent">
                    Continuar Comprando
                  </Button>
                </Link>
                <Button
                  className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground"
                  onClick={() => window.print()}
                >
                  Imprimir Pedido
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
