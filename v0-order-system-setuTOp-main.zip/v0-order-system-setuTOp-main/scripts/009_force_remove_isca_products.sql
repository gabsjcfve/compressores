-- Remove definitivamente os produtos de isca de peixe e carne
DELETE FROM produtos 
WHERE nome ILIKE '%isca de peixe%' 
   OR nome ILIKE '%isca de carne%'
   OR nome = 'Porção isca de peixe'
   OR nome = 'Porção isca de carne'
   OR nome = 'Porção Isca de Peixe'
   OR nome = 'Porção Isca de Carne';

-- Verificar produtos restantes
SELECT id, nome, preco FROM produtos ORDER BY nome;
