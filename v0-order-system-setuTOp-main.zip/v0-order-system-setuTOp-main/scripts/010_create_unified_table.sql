-- Criando tabela unificada para pedidos
-- Remove as tabelas antigas e cria uma única tabela com todos os dados
DROP TABLE IF EXISTS itens_pedido CASCADE;
DROP TABLE IF EXISTS pedidos CASCADE;
DROP TABLE IF EXISTS produtos CASCADE;

-- Tabela unificada que contém todos os dados do pedido
CREATE TABLE pedidos_completos (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    numero_pedido INTEGER NOT NULL,
    nome_produto VARCHAR(255) NOT NULL,
    quantidade INTEGER NOT NULL CHECK (quantidade > 0),
    preco_unitario DECIMAL(10,2) NOT NULL CHECK (preco_unitario > 0),
    subtotal DECIMAL(10,2) NOT NULL CHECK (subtotal > 0),
    total_pedido DECIMAL(10,2) NOT NULL CHECK (total_pedido > 0),
    forma_pagamento VARCHAR(20) NOT NULL CHECK (forma_pagamento IN ('pix', 'cartao', 'dinheiro')),
    cliente_nome VARCHAR(255) NOT NULL DEFAULT 'Cliente',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para melhor performance
CREATE INDEX idx_pedidos_completos_numero ON pedidos_completos(numero_pedido);
CREATE INDEX idx_pedidos_completos_created_at ON pedidos_completos(created_at);

-- Sequência para números de pedido
CREATE SEQUENCE IF NOT EXISTS numero_pedido_seq START 1;

-- Política RLS para acesso público
ALTER TABLE pedidos_completos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Permitir acesso público aos pedidos" ON pedidos_completos
    FOR ALL USING (true);

-- Inserir produtos base como referência (sem estoque)
CREATE TABLE produtos_menu (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    nome VARCHAR(255) NOT NULL UNIQUE,
    preco DECIMAL(10,2) NOT NULL CHECK (preco > 0),
    descricao TEXT,
    imagem TEXT DEFAULT '/placeholder.svg?height=300&width=300',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Política RLS para produtos
ALTER TABLE produtos_menu ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Permitir acesso público aos produtos" ON produtos_menu
    FOR ALL USING (true);

-- Inserir produtos do cardápio
INSERT INTO produtos_menu (nome, preco, descricao) VALUES
('Porção Fritas', 18.00, 'Porção de batata frita crocante'),
('Porção Palito de Queijo', 22.00, 'Porção de palitos de queijo empanados'),
('Lanche Natural', 15.00, 'Lanche natural com ingredientes frescos'),
('X Bacon', 28.00, 'Hambúrguer com bacon, queijo e salada'),
('X Salada', 25.00, 'Hambúrguer com salada completa'),
('X Burger', 30.00, 'Hambúrguer especial da casa'),
('Misto Quente', 12.00, 'Sanduíche misto quente tradicional'),
('Salada Sabbia', 20.00, 'Salada especial da casa'),
('Coca Cola', 5.00, 'Refrigerante Coca Cola 350ml'),
('Guaraná', 4.50, 'Refrigerante Guaraná 350ml');

-- Verificar dados inseridos
SELECT 'Produtos inseridos:' as info;
SELECT nome, preco FROM produtos_menu ORDER BY nome;
