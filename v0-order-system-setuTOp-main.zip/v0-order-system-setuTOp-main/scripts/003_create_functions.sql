-- Função para atualizar estoque
CREATE OR REPLACE FUNCTION atualizar_estoque(produto_id UUID, quantidade_vendida INTEGER)
RETURNS VOID AS $$
BEGIN
  UPDATE produtos 
  SET estoque = estoque - quantidade_vendida,
      updated_at = NOW()
  WHERE id = produto_id;
END;
$$ LANGUAGE plpgsql;
