-- Inserir produtos de exemplo
INSERT INTO produtos (nome, preco, estoque, descricao, imagem) VALUES
('Smartphone Galaxy S24', 2499.99, 15, 'Smartphone Samsung Galaxy S24 com 128GB de armazenamento', '/placeholder.svg?height=300&width=300'),
('Notebook Dell Inspiron', 3299.99, 8, 'Notebook Dell Inspiron 15 com Intel i5 e 8GB RAM', '/placeholder.svg?height=300&width=300'),
('Fone Bluetooth JBL', 299.99, 25, 'Fone de ouvido JBL Bluetooth com cancelamento de ruído', '/placeholder.svg?height=300&width=300'),
('Smart TV 55" LG', 2199.99, 12, 'Smart TV LG 55 polegadas 4K UHD com WebOS', '/placeholder.svg?height=300&width=300'),
('Mouse Gamer Logitech', 199.99, 30, 'Mouse gamer Logitech G502 com sensor óptico', '/placeholder.svg?height=300&width=300'),
('Teclado Mecânico RGB', 349.99, 20, 'Teclado mecânico com iluminação RGB e switches blue', '/placeholder.svg?height=300&width=300'),
('Tablet iPad Air', 3499.99, 10, 'iPad Air com tela de 10.9 polegadas e chip M1', '/placeholder.svg?height=300&width=300'),
('Câmera Canon EOS', 4299.99, 5, 'Câmera Canon EOS Rebel T7i com lente 18-55mm', '/placeholder.svg?height=300&width=300')
ON CONFLICT DO NOTHING;
