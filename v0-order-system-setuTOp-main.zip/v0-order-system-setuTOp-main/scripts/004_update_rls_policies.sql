-- Update RLS policies to allow public access without authentication

-- Drop existing policies
DROP POLICY IF EXISTS "Produtos são visíveis para todos" ON produtos;
DROP POLICY IF EXISTS "Pedidos podem ser criados por qualquer pessoa" ON pedidos;
DROP POLICY IF EXISTS "Itens de pedido podem ser criados por qualquer pessoa" ON itens_pedido;

-- Create new public access policies
CREATE POLICY "Public read access for produtos" ON produtos
  FOR SELECT USING (true);

CREATE POLICY "Public insert access for pedidos" ON pedidos
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Public read access for pedidos" ON pedidos
  FOR SELECT USING (true);

CREATE POLICY "Public insert access for itens_pedido" ON itens_pedido
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Public read access for itens_pedido" ON itens_pedido
  FOR SELECT USING (true);

-- Ensure RLS is enabled
ALTER TABLE produtos ENABLE ROW LEVEL SECURITY;
ALTER TABLE pedidos ENABLE ROW LEVEL SECURITY;
ALTER TABLE itens_pedido ENABLE ROW LEVEL SECURITY;
