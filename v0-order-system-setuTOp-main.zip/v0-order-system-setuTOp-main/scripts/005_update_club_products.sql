-- Updating products to club/bar items with proper pricing
DELETE FROM produtos;

INSERT INTO produtos (id, nome, preco, estoque, descricao, imagem) VALUES
  (gen_random_uuid(), 'Porção Fritas', 18.00, 50, 'Deliciosa porção de batatas fritas crocantes', '/placeholder.svg?height=300&width=300'),
  (gen_random_uuid(), 'Porção Isca de Peixe', 32.00, 30, 'Iscas de peixe empanadas e fritas', '/placeholder.svg?height=300&width=300'),
  (gen_random_uuid(), 'Porção Isca de Carne', 35.00, 25, 'Iscas de carne bovina temperadas', '/placeholder.svg?height=300&width=300'),
  (gen_random_uuid(), 'Porção Palito de Queijo', 22.00, 40, 'Palitos de queijo empanados e dourados', '/placeholder.svg?height=300&width=300'),
  (gen_random_uuid(), 'Lanche Natural', 15.00, 20, 'Sanduíche natural com ingredientes frescos', '/placeholder.svg?height=300&width=300'),
  (gen_random_uuid(), 'X Bacon', 28.00, 15, 'Hambúrguer com bacon, queijo e salada', '/placeholder.svg?height=300&width=300'),
  (gen_random_uuid(), 'X Salada', 24.00, 18, 'Hambúrguer com salada completa', '/placeholder.svg?height=300&width=300'),
  (gen_random_uuid(), 'X Burger', 26.00, 20, 'Hambúrguer tradicional com queijo', '/placeholder.svg?height=300&width=300'),
  (gen_random_uuid(), 'Misto Quente', 12.00, 35, 'Sanduíche misto quente tradicional', '/placeholder.svg?height=300&width=300'),
  (gen_random_uuid(), 'Salada Sabbia', 20.00, 25, 'Salada especial da casa com molho exclusivo', '/placeholder.svg?height=300&width=300');
