-- Remove isca de peixe e isca de carne, adiciona coca cola e guaraná

-- Remove produtos não desejados
DELETE FROM produtos WHERE nome IN ('Porção isca de peixe', 'Porção isca de carne');

-- Adiciona novas bebidas
INSERT INTO produtos (nome, preco, estoque, descricao, imagem) VALUES
('Coca Cola', 5.00, 50, 'Refrigerante Coca Cola 350ml', '/placeholder.svg?height=300&width=300'),
('Guaraná', 4.50, 50, 'Refrigerante Guaraná 350ml', '/placeholder.svg?height=300&width=300');
