-- Criar tabela de produtos menu se não existir
CREATE TABLE IF NOT EXISTS produtos_menu (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    nome VARCHAR(255) NOT NULL UNIQUE,
    preco DECIMAL(10,2) NOT NULL CHECK (preco > 0),
    descricao TEXT,
    imagem TEXT DEFAULT '/placeholder.svg?height=300&width=300',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Política RLS para produtos
ALTER TABLE produtos_menu ENABLE ROW LEVEL SECURITY;

-- Remover política existente se houver
DROP POLICY IF EXISTS "Permitir acesso público aos produtos" ON produtos_menu;

-- Criar nova política
CREATE POLICY "Permitir acesso público aos produtos" ON produtos_menu
    FOR ALL USING (true);

-- Limpar dados existentes e inserir produtos atualizados
DELETE FROM produtos_menu;

-- Inserir produtos do cardápio (sem isca de peixe e carne)
INSERT INTO produtos_menu (nome, preco, descricao) VALUES
('Porção Fritas', 18.00, 'Porção de batata frita crocante'),
('Porção Palito de Queijo', 22.00, 'Porção de palitos de queijo empanados'),
('Lanche Natural', 15.00, 'Lanche natural com ingredientes frescos'),
('X Bacon', 28.00, 'Hambúrguer com bacon, queijo e salada'),
('X Salada', 25.00, 'Hambúrguer com salada completa'),
('X Burger', 30.00, 'Hambúrguer especial da casa'),
('Misto Quente', 12.00, 'Sanduíche misto quente tradicional'),
('Salada Sabbia', 20.00, 'Salada especial da casa'),
('Coca Cola', 5.00, 'Refrigerante Coca Cola 350ml'),
('Guaraná', 4.50, 'Refrigerante Guaraná 350ml');

-- Verificar dados inseridos
SELECT 'Produtos no menu:' as info;
SELECT nome, preco FROM produtos_menu ORDER BY nome;
