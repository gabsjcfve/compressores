-- Remove produtos de isca de peixe e carne do cardápio
DELETE FROM produtos 
WHERE nome IN ('Porção isca de peixe', 'Porção isca de carne');

-- Verificar produtos restantes
SELECT nome, preco FROM produtos ORDER BY nome;
