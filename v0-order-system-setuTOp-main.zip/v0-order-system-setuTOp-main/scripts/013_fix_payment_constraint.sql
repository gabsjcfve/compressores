-- Corrigir constraint de forma de pagamento para aceitar cartão crédito e débito
-- Remove a constraint antiga e cria uma nova com os valores corretos

-- Primeiro, remove a constraint existente
ALTER TABLE pedidos_completos DROP CONSTRAINT IF EXISTS pedidos_completos_forma_pagamento_check;

-- Cria nova constraint com todos os valores aceitos
ALTER TABLE pedidos_completos 
ADD CONSTRAINT pedidos_completos_forma_pagamento_check 
CHECK (forma_pagamento IN ('pix', 'cartao_credito', 'cartao_debito', 'dinheiro', 'cartao'));

-- Verifica se a constraint foi criada corretamente
SELECT conname, consrc 
FROM pg_constraint 
WHERE conname = 'pedidos_completos_forma_pagamento_check';

-- Testa inserção com os novos valores
INSERT INTO pedidos_completos (
    numero_pedido, cliente_nome, forma_pagamento, total_pedido,
    nome_produto, quantidade, preco_unitario, subtotal
) VALUES (
    999999, 'Teste Constraint', 'cartao_credito', 10.00,
    'Teste Produto', 1, 10.00, 10.00
);

-- Remove o registro de teste
DELETE FROM pedidos_completos WHERE numero_pedido = 999999;

SELECT 'Constraint atualizada com sucesso!' as status;
