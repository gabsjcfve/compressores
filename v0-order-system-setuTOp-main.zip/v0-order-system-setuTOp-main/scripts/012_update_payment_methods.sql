-- Atualizar constraint de forma de pagamento para incluir cartão crédito e débito separados
ALTER TABLE pedidos_completos DROP CONSTRAINT IF EXISTS pedidos_completos_forma_pagamento_check;

-- Adicionar nova constraint com as opções separadas
ALTER TABLE pedidos_completos ADD CONSTRAINT pedidos_completos_forma_pagamento_check 
CHECK (forma_pagamento IN ('pix', 'cartao_credito', 'cartao_debito', 'dinheiro'));

-- Verificar se a constraint foi aplicada corretamente
SELECT conname, consrc 
FROM pg_constraint 
WHERE conname = 'pedidos_completos_forma_pagamento_check';
