-- Update pedidos table to allow NULL or default values for optional fields
ALTER TABLE pedidos 
ALTER COLUMN cliente_email SET DEFAULT 'N/A',
ALTER COLUMN cliente_telefone SET DEFAULT 'N/A', 
ALTER COLUMN cliente_endereco SET DEFAULT 'N/A';

-- Update existing NULL values to default
UPDATE pedidos 
SET 
  cliente_email = COALESCE(cliente_email, 'N/A'),
  cliente_telefone = COALESCE(cliente_telefone, 'N/A'),
  cliente_endereco = COALESCE(cliente_endereco, 'N/A')
WHERE cliente_email IS NULL OR cliente_telefone IS NULL OR cliente_endereco IS NULL;
