-- Força a atualização da constraint de forma_pagamento para aceitar cartão crédito e débito
-- Remove a constraint existente e cria uma nova

-- Primeiro, vamos verificar se a tabela existe e qual constraint está ativa
DO $$
BEGIN
    -- Remove a constraint existente se ela existir
    IF EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE constraint_name = 'pedidos_completos_forma_pagamento_check' 
        AND table_name = 'pedidos_completos'
    ) THEN
        ALTER TABLE pedidos_completos DROP CONSTRAINT pedidos_completos_forma_pagamento_check;
        RAISE NOTICE 'Constraint antiga removida com sucesso';
    END IF;
    
    -- Adiciona a nova constraint com os valores corretos
    ALTER TABLE pedidos_completos 
    ADD CONSTRAINT pedidos_completos_forma_pagamento_check 
    CHECK (forma_pagamento IN ('pix', 'cartao_credito', 'cartao_debito', 'dinheiro'));
    
    RAISE NOTICE 'Nova constraint criada com sucesso';
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Erro ao atualizar constraint: %', SQLERRM;
END $$;

-- Verifica se a constraint foi criada corretamente
SELECT 
    constraint_name, 
    check_clause 
FROM information_schema.check_constraints 
WHERE constraint_name = 'pedidos_completos_forma_pagamento_check';

-- Testa os novos valores
INSERT INTO pedidos_completos (
    numero_pedido, cliente_nome, forma_pagamento, total_pedido,
    nome_produto, quantidade, preco_unitario, subtotal
) VALUES (
    999999, 'Teste Constraint', 'cartao_credito', 10.00,
    'Produto Teste', 1, 10.00, 10.00
);

-- Remove o registro de teste
DELETE FROM pedidos_completos WHERE numero_pedido = 999999;

SELECT 'Constraint atualizada e testada com sucesso!' as resultado;
